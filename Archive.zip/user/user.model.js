const sql = require("../_helpers/db.js");
const tableName = "users";

// constructor
const User = function(user) {
  this.name = user.name;
  this.phone = user.phone;
  this.mac = user.mac;
};

const ModelName = User;

ModelName.create = (newUser, result) => {
  sql.query(`INSERT INTO ${tableName} SET ?`, newUser, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created user: ", { id: res.insertId, ...newUser });
    result(null, { id: res.insertId, ...newUser });
  });
};

ModelName.findById = (customerId, result) => {
  sql.query(`SELECT * FROM ${tableName} WHERE id = ${customerId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

ModelName.getAll = result => {
  sql.query(`SELECT * FROM ${tableName}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("users: ", res);
    result(null, res);
  });
};

ModelName.updateById = (id, customer, result) => {
  sql.query(
    `UPDATE ${tableName} SET name = ?, phone = ?, mac = ? WHERE id = ?`,
    [customer.name, customer.phone, customer.mac, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Customer with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated user: ", { id: id, ...customer });
      result(null, { id: id, ...customer });
    }
  );
};

ModelName.remove = (id, result) => {
  sql.query(`DELETE FROM ${tableName} WHERE id = ?`, id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted user with id: ", id);
    result(null, res);
  });
};



module.exports = ModelName;